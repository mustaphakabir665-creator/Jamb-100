# JAMB 100% — Complete Full-Stack Website

This package upgrades the earlier frontend prototype into a deployable Node.js + PostgreSQL application.

## Included
- Student registration/login with hashed passwords
- Student profiles and server-side progress
- Free Learning Centre
- JAMB CBT API with randomized question selection
- Attempt/result storage
- NDA and POLAC preparation sections
- Four separate paid products at ₦1,500
- Payment screenshot upload stored in PostgreSQL
- Payment request automatically tied to registered student email
- Admin login with server-side hashed password
- Admin dashboard, students, payments, screenshot viewing, product access and revoke
- Product-specific approval: approving one payment unlocks only that product
- Announcements API
- Render deployment configuration
- Android APK download route ready for a signed APK

## Important
The package contains a small seeded question set so the system can run immediately. The production question bank should be populated through the admin/backend before launch. Do not claim 1,000 questions per subject until that bank has actually been imported.

The APK route is ready, but an actual signed APK is not included because this environment cannot compile/sign an Android release. After building the Android app, copy the signed APK to `downloads/jamb100.apk`.

## Local setup
1. Install Node.js 20+ and PostgreSQL.
2. Create a PostgreSQL database.
3. Copy `.env.example` to `.env` and fill in values.
4. Set ADMIN_EMAIL and ADMIN_PASSWORD to the administrator credentials you want to use. Never put the password in frontend code.
5. Run `npm install`.
6. Run `npm run seed-admin` once.
7. Run `npm start`.
8. Open `http://localhost:10000`.

## Render deployment
1. Push this folder to a private GitHub repository.
2. Create a PostgreSQL database on your chosen provider.
3. Create a Render Web Service from the GitHub repository.
4. Build command: `npm install`
5. Start command: `npm start`
6. Add environment variables from `.env.example`.
7. Deploy.
8. Run the admin seed command against the production database (or seed the admin using a one-off job/shell if your host provides it).

## Security
- Use a strong random JWT_SECRET.
- Use HTTPS.
- Keep DATABASE_URL and ADMIN_PASSWORD in server environment variables.
- Payment screenshots are stored in PostgreSQL as binary data.
- The admin API requires an admin JWT.
- Students cannot call admin endpoints with a student token.

## Android
The website has a Download APK button and serves `/downloads/jamb100.apk`. Upload a properly signed release APK with exactly that filename when the Android build is ready.


## JAMB Mock
The paid JAMB Mock now exposes all 25 UTME subjects. One approved JAMB Mock purchase unlocks subject selection; each selected subject launches the mock practice flow.
